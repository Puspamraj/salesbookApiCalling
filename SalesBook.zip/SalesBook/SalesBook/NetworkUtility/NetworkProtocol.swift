//
//  NetworkProtocol.swift
//  SalesBook
//
//  Created by Pushpam on 05/09/21.
//

import Foundation

protocol NetworkDelegate : NSObjectProtocol {
    
    func userDetailsResponse(userDetails:[UserDetials], creditModel:CreditModel?, error:Error?)
    
}
