//
//  ServerRequest.swift
//  SalesBook
//
//  Created by Pushpam on 04/09/21.
//



import Foundation

let token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwaG9uZSI6IjkxODg0NzI0MDg4MyIsInVzZXJJRCI6IjYwNTFhZGFlZTYwYzk5NTFhMGJiYzYzMyIsImlhdCI6MTYyNzAyMjMwN30.9JKFw22EuwQqCjnYawooopPRAoHxptQN85FH-O-X9BY"



class ServerRequest : NSObject {
        
    
    let url = URL(string: "https://dev.salesbooks.in/api/V2/business-contacts/")
    weak var delegate:NetworkDelegate?
 
    // using protocol
    func getAllUserData(){
      
        var request : URLRequest = URLRequest(url: url!)
        request.url = url
        request.httpMethod = "GET"
        request.timeoutInterval = 30
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        
                let dataTask = URLSession.shared.dataTask(with: request) { [self] (data, response, error) in
           
            if (error != nil) {
                print("error: \(error.debugDescription)")
                delegate?.userDetailsResponse(userDetails: [], creditModel: nil, error: error)
                
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, let receivedData = data else {
                print("error: not a valid http response")
                delegate?.userDetailsResponse(userDetails: [], creditModel: nil, error: error)
                return
            }
            
            var finalUserList:[UserDetials] = [UserDetials]()
            switch (httpResponse.statusCode) {
            
            case 200:
                let responseJSON = try? JSONSerialization.jsonObject(with: receivedData, options: [])
                    if let responseJSON = responseJSON as? [String: Any], let userList =  responseJSON["data"] as? [[String: Any]] {
                        print(responseJSON)
                                                
                        let creditObj = try? JSONDecoder().decode(CreditModel.self, from: receivedData)
                        
                        for user in userList {
                            let encoded  = try? JSONSerialization.data(withJSONObject: user, options: [])
                            if let userObj = try? JSONDecoder().decode(UserDetials.self, from: encoded!) {
                              finalUserList.append(userObj)
                            }
                        }
                        
                        delegate?.userDetailsResponse(userDetails: finalUserList, creditModel: creditObj, error: error)
                    }
            default:
                print("save profile POST request got response \(httpResponse.statusCode)")
                delegate?.userDetailsResponse(userDetails: [], creditModel: nil, error: error)
            }
        }
        dataTask.resume()
    }
    
    // using block
    static func getAllUserDataWithBlock( completionBlock:@escaping ((_ userDetails:[UserDetials], _ creditModel:CreditModel?, _ error:Error?) -> Void)){
      
        let url = URL(string: "https://dev.salesbooks.in/api/V2/business-contacts/")

        var request : URLRequest = URLRequest(url: url!)
        request.url = url
        request.httpMethod = "GET"
        request.timeoutInterval = 30
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        
       
        let dataTask = URLSession.shared.dataTask(with: request) { (data, response, error) in
           
            if (error != nil) {
                print("error: \(error.debugDescription)")
                completionBlock([], nil, error)
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, let receivedData = data else {
                print("error: not a valid http response")
                completionBlock([], nil, error)
                
                return
            }
            
            var finalUserList:[UserDetials] = [UserDetials]()
            switch (httpResponse.statusCode) {
            
            case 200:
                let responseJSON = try? JSONSerialization.jsonObject(with: receivedData, options: [])
                    if let responseJSON = responseJSON as? [String: Any], let userList =  responseJSON["data"] as? [[String: Any]] {
                        print(responseJSON)
                                                
                        let creditObj = try? JSONDecoder().decode(CreditModel.self, from: receivedData)
                        
                        for user in userList {
                            let encoded  = try? JSONSerialization.data(withJSONObject: user, options: [])
                            if let userObj = try? JSONDecoder().decode(UserDetials.self, from: encoded!) {
                              finalUserList.append(userObj)
                            }
                        }
                        
                        completionBlock(finalUserList, creditObj, error)
                    }
            default:
                print("save profile POST request got response \(httpResponse.statusCode)")
                completionBlock([], nil, error)

            }
        }
        dataTask.resume()
    }
    
}

