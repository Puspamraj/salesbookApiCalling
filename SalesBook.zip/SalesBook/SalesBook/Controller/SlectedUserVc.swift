//
//  SlectedUserVc.swift
//  SalesBook
//
//  Created by Pushpam on 04/09/21.
//

import Foundation
import UIKit

class SelectedUserVc: UIViewController {
    
    var userModelRcv:String?
    
  
    @IBOutlet weak var userImage: UIImageView!
    
    @IBOutlet weak var selectedUserName: UILabel!
    
    
    override func viewDidLoad() {
        userImage.image = #imageLiteral(resourceName: "image7.png")
              selectedUserName.text = userModelRcv
    }
    
}
