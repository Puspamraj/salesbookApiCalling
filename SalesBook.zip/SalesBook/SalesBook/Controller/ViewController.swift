//
//  ViewController.swift
//  SalesBook
//
//  Created by Pushpam on 03/09/21.
//

import UIKit
import MBProgressHUD

class ViewController: UIViewController {

    @IBOutlet weak var creditGivenLbl: UILabel!
    @IBOutlet weak var creditTakenLbl: UILabel!
    @IBOutlet weak var activeOrder1: UILabel!
    @IBOutlet weak var activeOrder2: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    var serverRequest = ServerRequest()
    var userModelList = [UserDetials]()
    var credtiModel:CreditModel?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.reloadData()
        serverRequest.delegate = self
        
            self.callAPI()
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    func showAlert(msg:String) {
        let alertVC = UIAlertController.init(title: "Alert", message: msg, preferredStyle: .alert)
        let ok = UIAlertAction.init(title: "OK", style: .default) { (alert) in
        }
        alertVC.addAction(ok)
        self.present(alertVC, animated: true, completion: nil)
    }
    

    
    
    func callAPI() {
       
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        self.serverRequest.getAllUserData()
        
//        ServerRequest.getAllUserDataWithBlock { (userList, creditModel, error) in
//            DispatchQueue.main.async {
//                MBProgressHUD.hide(for: self.view, animated: true)
//                if error != nil {
//                    // show error alert
//                    print(error?.localizedDescription)
//                }
//                else {
//                    self.userModelList = userList
//                    self.credtiModel = creditModel
//                }
//
//                self.tableView.reloadData()
//            }
//        }
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userModelList.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        let tempUser = userModelList[indexPath.row]
        
        
        var namefirst = tempUser.name.first
        print(namefirst!)
        
        cell.nameLbl.text = tempUser.name
        cell.msgLbl.text = "This is a dummy message"
        cell.singleLetterLbl.text = "\(namefirst!)"
        cell.timeLbl.text = "12:12"
        
        creditGivenLbl.text = credtiModel?.totalCreditGiven
        creditTakenLbl.text = credtiModel?.totalCreditTaken
        activeOrder1.text = credtiModel?.totalOrder
        activeOrder2.text = credtiModel?.totalActiveOrder
        
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
         let tempUser = userModelList[indexPath.row]
        
        
        let selectedUserVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "SelectedUserVc") as! SelectedUserVc
        selectedUserVC.userModelRcv = "\(tempUser.name)"
        self.navigationController?.pushViewController(selectedUserVC, animated: true)
    }
}

extension ViewController: NetworkDelegate {
    
    
    func userDetailsResponse(userDetails: [UserDetials], creditModel: CreditModel?, error: Error?) {
        DispatchQueue.main.async {
            MBProgressHUD.hide(for: self.view, animated: true)

            if error != nil {
                // show error alert
                print(error.debugDescription)
                self.showAlert(msg: "The Internet connection appears to be offline")
                
            }
            else {
                self.userModelList = userDetails
                self.credtiModel = creditModel
            }
            
            self.tableView.reloadData()
        }
    }
    
    
    
}
