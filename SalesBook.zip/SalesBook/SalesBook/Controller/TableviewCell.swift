//
//  TableviewCell.swift
//  SalesBook
//
//  Created by Pushpam on 04/09/21.
//

import Foundation
import UIKit

class TableViewCell: UITableViewCell{
    @IBOutlet weak var singleLetterLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var msgLbl: UILabel!
    @IBOutlet weak var timeLbl: UILabel!
    
    
}
