//
//  UserDetails.swift
//  SalesBook
//
//  Created by Pushpam on 04/09/21.
//

import Foundation

struct UserDetials : Codable {
    let _id : String
    let name : String
    let phone : String
    let date : String
    
    enum CodingKeys: String, CodingKey {
        
        case _id = "_id"
        case name = "name"
        case phone = "phone"
        case date = "date"
    
    
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        _id = try values.decodeIfPresent(String.self, forKey: ._id) ?? ""
        name = try values.decodeIfPresent(String.self, forKey: .name) ?? ""
        phone = try values.decodeIfPresent(String.self, forKey: .phone) ?? ""
        date = try values.decodeIfPresent(String.self, forKey: .date) ?? ""
    
    }
    
}

struct CreditModel : Codable {
    let totalCreditGiven : String
    let totalCreditTaken : String
    let totalOrder : String
    let totalActiveOrder : String
  

    enum CodingKeys: String, CodingKey {

        case totalCreditGiven = "totalCreditGiven"
        case totalCreditTaken = "totalCreditTaken"
        case totalOrder = "totalOrder"
        case totalActiveOrder = "totalActiveOrder"
    
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        totalCreditGiven = try values.decodeIfPresent(String.self, forKey: .totalCreditGiven) ?? ""
        totalCreditTaken = try values.decodeIfPresent(String.self, forKey: .totalCreditTaken) ?? ""
        totalOrder = try values.decodeIfPresent(String.self, forKey: .totalOrder) ?? ""
        totalActiveOrder = try values.decodeIfPresent(String.self, forKey: .totalActiveOrder) ?? ""

    }

}
